# -*- coding: utf-8 -*-
"""
CNINE 별풍선표 자동 변환기

기능:
- 엑셀부 ranking.html / 스타부 ranking.html을 읽어서 ranking_data.json 생성
- 경로는 paths_config.json에 저장된 값을 사용
- paths_config.json이 없으면 파일 선택 창으로 선택
- GitHub Pages의 index.html은 ranking_data.json을 읽어서 낙수표 출력

실행:
python update_rank_table.py
"""

import json
import re
import html as htmlmod
import shutil
from pathlib import Path
from datetime import datetime
from tkinter import Tk, filedialog, messagebox

CONFIG_FILE = "paths_config.json"
OUT_FILE = "ranking_data.json"

def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def ask_file(title):
    root = Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    path = filedialog.askopenfilename(title=title, filetypes=[("HTML files", "*.html"), ("All files", "*.*")])
    root.destroy()
    return path

def ask_folder(title):
    root = Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    path = filedialog.askdirectory(title=title)
    root.destroy()
    return path

def load_or_select_config():
    p = Path(CONFIG_FILE)
    if p.exists():
        try:
            cfg = json.loads(p.read_text(encoding="utf-8"))
            if cfg.get("excel_html") and cfg.get("star_html"):
                return cfg
        except Exception:
            pass

    excel = ask_file("엑셀부 ranking.html 선택")
    if not excel:
        raise SystemExit("엑셀부 파일 선택 취소")
    star = ask_file("스타부 ranking.html 선택")
    if not star:
        raise SystemExit("스타부 파일 선택 취소")
    github_dir = ask_folder("GitHub poong-rank 폴더 선택")
    cfg = {"excel_html": excel, "star_html": star, "github_dir": github_dir}
    p.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return cfg

def extract_card(doc, crew_title):
    marker = f'<div class="crew-title">{crew_title}</div>'
    idx = doc.find(marker)
    if idx < 0:
        raise ValueError(f"카드를 찾지 못함: {crew_title}")
    start = doc.rfind('<div class="card', 0, idx)
    if start < 0:
        raise ValueError(f"카드 시작을 찾지 못함: {crew_title}")

    tag_re = re.compile(r'</?div\b[^>]*>', re.I)
    depth = 0
    end = None
    for m in tag_re.finditer(doc, start):
        tag = m.group(0)
        if tag.startswith("</"):
            depth -= 1
            if depth == 0:
                end = m.end()
                break
        else:
            depth += 1
    if end is None:
        raise ValueError(f"카드 끝을 찾지 못함: {crew_title}")
    return doc[start:end]

def clean_text(s):
    s = re.sub(r"<.*?>", "", s or "", flags=re.S)
    return htmlmod.unescape(s).strip()

def get_text(card, pattern, default=""):
    m = re.search(pattern, card, re.S)
    return clean_text(m.group(1)) if m else default

def parse_card(doc, crew_title):
    card = extract_card(doc, crew_title)

    logo = ""
    m = re.search(r'<img class="crew-logo" src="([^"]+)"', card)
    if m:
        logo = htmlmod.unescape(m.group(1))

    top_style = ""
    m = re.search(r'<div class="top" style="([^"]+)"', card)
    if m:
        top_style = m.group(1)

    color = "#7dc7ff"
    m = re.search(r'--c:([^;]+);', card)
    if m:
        color = m.group(1).strip()

    row_re = re.compile(
        r'<div class="row([^"]*)" style="--w:([^;]+);--c:([^;]+);">\s*'
        r'<div class="rank">(.*?)</div>\s*'
        r'<div class="name">(.*?)</div>\s*'
        r'<div class="today-mini[^"]*">(.*?)</div>\s*'
        r'<div class="score[^"]*">(.*?)</div>\s*</div>',
        re.S
    )

    members = []
    for rm in row_re.finditer(card):
        members.append({
            "rank": clean_text(rm.group(4)),
            "name": clean_text(rm.group(5)),
            "today": clean_text(rm.group(6)),
            "month": clean_text(rm.group(7)),
            "width": rm.group(2).strip(),
            "color": rm.group(3).strip(),
            "first": "first" in rm.group(1),
        })

    return {
        "crew": crew_title,
        "rank_badge": get_text(card, r'<div class="rank-badge">(.*?)</div>'),
        "logo": logo,
        "avg": get_text(card, r'<div class="avg-num">(.*?)</div>'),
        "leader": get_text(card, r'<div class="sales-sub">(.*?)</div>'),
        "leader_sales": get_text(card, r'<div class="sales">\s*<span>.*?</span>\s*<span>(.*?)</span>'),
        "top_style": top_style,
        "color": color,
        "members": members,
    }

def get_update_time(doc):
    m = re.search(r'<div class="update-time">집계시간:\s*([^<]+)</div>', doc)
    return clean_text(m.group(1)) if m else ""

def main():
    cfg = load_or_select_config()

    excel_path = Path(cfg["excel_html"])
    star_path = Path(cfg["star_html"])

    if not excel_path.exists():
        print("[ERROR] 엑셀부 파일 없음:", excel_path)
        return 1
    if not star_path.exists():
        print("[ERROR] 스타부 파일 없음:", star_path)
        return 1

    excel_doc = excel_path.read_text(encoding="utf-8", errors="ignore")
    star_doc = star_path.read_text(encoding="utf-8", errors="ignore")

    data = {
        "updated_at": get_update_time(excel_doc) or get_update_time(star_doc) or now_str(),
        "generated_at": now_str(),
        "excel_source": str(excel_path),
        "star_source": str(star_path),
        "excel": parse_card(excel_doc, "씨나인엑셀"),
        "star": parse_card(star_doc, "씨나인"),
    }

    Path(OUT_FILE).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    # Keep source copies for GitHub/debug
    shutil.copy2(excel_path, "ranking_excel_source.html")
    shutil.copy2(star_path, "ranking_star_source.html")

    print("=" * 60)
    print("완료:", OUT_FILE)
    print("엑셀부:", len(data["excel"]["members"]), "명")
    print("스타부:", len(data["star"]["members"]), "명")
    print("집계시간:", data["updated_at"])
    print("=" * 60)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
