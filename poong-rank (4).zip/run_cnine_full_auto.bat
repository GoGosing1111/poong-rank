@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo CNINE_FULL_AUTO_START

echo.
echo STEP_1
call run_update_and_push.bat
echo STEP_1_RETURN=%errorlevel%
pause

echo.
echo STEP_2
call run_make_ygosu_c9_dashboard.bat
echo STEP_2_RETURN=%errorlevel%
pause

echo.
echo STEP_3
python auto_edit_ygosu_c9_dashboard.py
echo STEP_3_RETURN=%errorlevel%
pause

echo.
echo ALL_DONE
pause